﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

// https://www.c-sharpcorner.com/article/create-custom-dependency-property-in-wpf/

namespace TestBinding
{
    public class TestControl : Label 
    {
        public static readonly DependencyProperty dependencyPropertyTestInfo =
            DependencyProperty.Register("TestInfo", typeof(string), typeof(TestControl),
                new PropertyMetadata("", new PropertyChangedCallback(ChangeTestInfo)));

        public string TestInfo
        {
            get => (string)GetValue(dependencyPropertyTestInfo);
            set => SetValue(dependencyPropertyTestInfo, value);
        }
        private static void ChangeTestInfo(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var testControl = (TestControl)d;
            testControl.TestInfo = (string)e.NewValue;
        }
    }
}
