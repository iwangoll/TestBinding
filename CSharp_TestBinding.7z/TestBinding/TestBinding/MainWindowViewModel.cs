﻿using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Diagnostics;
using System.Reflection;

namespace TestBinding
{
    public class MainWindowViewModel : BindableBase
    {
        private int counter;
        private string _testInfoView;
        public string TestInfoView
        {
            get { return _testInfoView; }
            set { SetProperty(ref _testInfoView, value); }
        }
        public DelegateCommand NewTestInfoCommand { get; }
        public MainWindowViewModel()
        {
            NewTestInfoCommand = new DelegateCommand(OnNewTestInfoCommand);
            TestInfoView = "Info from ctor";
        }
        private void OnNewTestInfoCommand()
        {
            string newInfo = $"Info No. {++counter}";
            Debug.WriteLine($"{MethodBase.GetCurrentMethod().Name}: {nameof(TestInfoView)}=«{TestInfoView}» -> «{newInfo}»");
            TestInfoView = newInfo;
        }
    }
}
